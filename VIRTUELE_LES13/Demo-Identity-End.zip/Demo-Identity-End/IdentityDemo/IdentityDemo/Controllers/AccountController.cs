﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Security.Claims;
using System.Threading.Tasks;
using AutoMapper;
using EmailService;
using IdentityDemo.Models;
using Microsoft.AspNetCore.Authentication;
using Microsoft.AspNetCore.Identity;
using Microsoft.AspNetCore.Mvc;
//STAP 11; STAP new MVC controller with two actions inside
//AccountController
//STAP 12: STAP view Register.cshtml for GET Register action under Views/Account folder
/*STAP 17: with the user registration logic, 
*we have to inject our AutoMapper and UserManager class in the Account controller
*/
namespace IdentityDemo.Controllers
{
    public class AccountController : Controller
    {
      
        //STAP 40: inject this email service in the Account controller:
        private readonly IEmailSender _emailSender;
        //STAP 34: SignInManager: private field + constructor
        private readonly SignInManager<IdentityUser> _signInManager;
        //STAP 18: 2 private fields + constructor
        private readonly IMapper _mapper;
        private readonly UserManager<IdentityUser> _userManager;
        public AccountController(IMapper mapper, UserManager<IdentityUser> userManager, SignInManager<IdentityUser> signInManager, IEmailSender emailSender)
        {
            _mapper = mapper;
            _userManager = userManager;
            _signInManager = signInManager; //STAP 34 SignInManager
            _emailSender = emailSender; //STAP 40 emailSender
        }


        [HttpGet]
        public IActionResult Register()
        {
            return View();
        }

        [HttpPost]
        [ValidateAntiForgeryToken]
        public async Task<IActionResult> Register(UserRegistrationModel userModel)
        {
            /*STAP 19: content of HTTP POST Register action and async Task
           // return View();*/
            /* Inside the action, we check for the model validity 
             * and if it is invalid, 
             * we just return the same view with the invalid model
             * If that check passes, we map the registration model to the user.
             * Additionally, we use the CreateAsync method to register the user.
             * But this method does more for us. It hashes a password, 
             * executes an additional user checks and returns a result.
             * If the result is successful, we just attach the default role to 
             * the user, 
             *  again with the UserManager’s help, and redirect the user 
             *  to the Index page.
             * But if the registration fails, we loop through all the errors 
             * and add them to the ModelState.
            */
            if (!ModelState.IsValid)
            {
                return View(userModel);
            }

            var user = _mapper.Map<IdentityUser>(userModel);

            var result = await _userManager.CreateAsync(user, userModel.Password);
            if (!result.Succeeded)
            {
                foreach (var error in result.Errors)
                {
                    ModelState.TryAddModelError(error.Code, error.Description);
                }

                return View(userModel);
            }

            await _userManager.AddToRoleAsync(user, "Visitor");

            return RedirectToAction(nameof(HomeController.Index), "Home");
        }

        //STAP 26: wo new actions Login to the Account controller:
        [HttpGet]
        public IActionResult Login(string returnUrl=null)
        {
            ViewData["ReturnUrl"] = returnUrl; //STAP 30 : returnUrl
            return View();
        }

        [HttpPost]
        [ValidateAntiForgeryToken]
        public async Task<IActionResult> Login(UserLoginModel userModel, string returnUrl = null)//STAP 32: returnUrl
        {
            //STAP 28: contents //return View();
            if (!ModelState.IsValid)
            {
                return View(userModel);
            }

            var user = await _userManager.FindByEmailAsync(userModel.Email);
            if (user != null &&
                await _userManager.CheckPasswordAsync(user, userModel.Password))
            {
                var identity = new ClaimsIdentity(IdentityConstants.ApplicationScheme);
                identity.AddClaim(new Claim(ClaimTypes.NameIdentifier, user.Id));
                identity.AddClaim(new Claim(ClaimTypes.Name, user.UserName));
                //STAP 32 en 33: wijzig in signInmanager
                //var result = await HttpContext.SignInAsync(IdentityConstants.ApplicationScheme,
                //    new ClaimsPrincipal(identity));
                var result = await _signInManager.PasswordSignInAsync(userModel.Email, userModel.Password, userModel.RememberMe, false);
                /*STAP 34 if successed else...
                //return RedirectToAction(nameof(HomeController.Index), "Home");
                //STAP 35: Test app en login
                */
                if (result.Succeeded)
                {
                    return RedirectToLocal(returnUrl);
                }
                else
                {
                    ModelState.AddModelError("", "Invalid UserName or Password");
                    return View();
                }
            }
            else
            {
                ModelState.AddModelError("", "Invalid UserName or Password");
                return View();
            }
            /*First, we check if the model is invalid and if it is,
             * we just return a view with the model.
             * After that, we use the FindByEmailAsync method from UserManager to return a user by email. 
             * If the user exists and the password matches the hashed password from the database, 
             * we create the ClaimsIdentity object with two claims inside (Id and UserName). 
             * Then, we sign in the user with the SignInAsync method by providing the scheme parameter 
             * and the claims principal. This will create the Identity.Application cookie in our browser. 
             * Finally, we redirect the user to the Index action.
             * If the user doesn’t exist in the database or the password doesn’t match, 
             * we return a view with the appropriate message.*/
        }
        //STAP 32: RedirectToLocal(string returnUrl)
        private IActionResult RedirectToLocal(string returnUrl)
        {
            if (Url.IsLocalUrl(returnUrl))
                return Redirect(returnUrl);
            else
                return RedirectToAction(nameof(HomeController.Index), "Home");
        }

        //STAP 37: Logout() action method
        [HttpPost]
        [ValidateAntiForgeryToken]
        public async Task<IActionResult> Logout()
        {
            await _signInManager.SignOutAsync();

            return RedirectToAction(nameof(HomeController.Index), "Home");
        }
        //STAP 41: ForgotPassword action method
        [HttpGet]
        public IActionResult ForgotPassword()
        {
            return View();
        }
        //STAP 44: ForgotPassword post action method
        [HttpPost]
        [ValidateAntiForgeryToken]
        public async Task<IActionResult> ForgotPassword(ForgotPasswordModel forgotPasswordModel)
        {
            if (!ModelState.IsValid)
                return View(forgotPasswordModel);

            var user = await _userManager.FindByEmailAsync(forgotPasswordModel.Email);
            if (user == null)
                return RedirectToAction(nameof(ForgotPasswordConfirmation));

            var token = await _userManager.GeneratePasswordResetTokenAsync(user);
            var callback = Url.Action(nameof(ResetPassword), "Account", new { token, email = user.Email }, Request.Scheme);

            var message = new Message(new string[] { user.Email }, "Reset password token", callback, null);
            await _emailSender.SendEmailAsync(message);

            return RedirectToAction(nameof(ForgotPasswordConfirmation));
        }

        /*So, if the model is valid we get the user from the database by its email. 
 * If they don’t exist,
 * we don’t create a message that the user with the provided email doesn’t exist in the database, but just redirect that user to the confirmation page.
 *This is a good practice for security reasons.
 * If they exist,bwe generate a token with the GeneratePasswordResetTokenAsync method 
 * and create a callback link to the action we are going to use for the reset logic.
 * Finally, we send an email message to the provided email address and redirect the 
 * user to the ForgotPasswordConfirmation view. With this setup,
 * we are missing two important things.
 * The token can’t be created and we don’t have the ResetPassword actions. 
 * So, let’s fix that.*/
        public IActionResult ForgotPasswordConfirmation()
        {
            return View();
        }
        [HttpGet]
        public IActionResult ResetPassword(string token, string email)
        {
            var model = new ResetPasswordModel { Token = token, Email = email };
            return View(model);
        }

        [HttpPost]
        [ValidateAntiForgeryToken]
        public async Task<IActionResult> ResetPassword(ResetPasswordModel resetPasswordModel)
        {
            if (!ModelState.IsValid)
                return View(resetPasswordModel);

            var user = await _userManager.FindByEmailAsync(resetPasswordModel.Email);
            if (user == null)
                RedirectToAction(nameof(ResetPasswordConfirmation));

            var resetPassResult = await _userManager.ResetPasswordAsync(user, resetPasswordModel.Token, resetPasswordModel.Password);
            if (!resetPassResult.Succeeded)
            {
                foreach (var error in resetPassResult.Errors)
                {
                    ModelState.TryAddModelError(error.Code, error.Description);
                }

                return View();
            }

            return RedirectToAction(nameof(ResetPasswordConfirmation));
        }

        [HttpGet]
        public IActionResult ResetPasswordConfirmation()
        {
            return View();
        }


    }
}
 