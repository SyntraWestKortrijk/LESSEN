using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;
using AutoMapper;
using EmailService;
using IdentityDemo.Factory;
using IdentityDemo.Models;
using Microsoft.AspNetCore.Builder;
using Microsoft.AspNetCore.Hosting;
using Microsoft.AspNetCore.HttpsPolicy;
using Microsoft.AspNetCore.Identity;
using Microsoft.EntityFrameworkCore;
using Microsoft.Extensions.Configuration;
using Microsoft.Extensions.DependencyInjection;
using Microsoft.Extensions.Hosting;
/*Introducing Identity to the ASP.NET Core Project
 * https://code-maze.com/identity-asp-net-core-project/
 * STAP 0 PM> "Microsoft.AspNetCore.Identity.EntityFrameworkCore" Version="3.1.0"
 * STAP 4 PM> Add-Migration CreatingIdentityScheme
 * STAP 5 PM> Update-Database   -> look at database
 */
/*STAP 13 AutoMapper is a simple library that helps us to transform one object type to another.
 * https://code-maze.com/automapper-net-core/
* PM> Install-Package AutoMapper.Extensions.Microsoft.DependencyInjection
*/
namespace IdentityDemo
{
    public class Startup
    {
        public Startup(IConfiguration configuration)
        {
            Configuration = configuration;
        }

        public IConfiguration Configuration { get; }

        // This method gets called by the runtime. Use this method to add services to the container.
        //STAP 22  modify  password to fulfill certain rules 
        //via the AddIdentity method in the ConfigureServices method
        public void ConfigureServices(IServiceCollection services)
        {
            services.AddDbContext<ApplicationContext>(opts =>
                opts.UseSqlServer(Configuration.GetConnectionString("sqlConnection")));
           
            /*If your project requires those features and any additional ones 
             * like supporting Roles not only Users, supporting external authentication 
             * and SingInManager,
             * as our application does, you have to use the AddIdentity method.*/
            services.AddIdentity<IdentityUser, IdentityRole>(opt => 
                {
                    opt.Password.RequiredLength = 4;
                    opt.Password.RequireDigit = false;
                    opt.Password.RequireUppercase = false;
                    opt.Password.RequireNonAlphanumeric = false;
                }) 
               .AddEntityFrameworkStores<ApplicationContext>()//STAP 3
                .AddDefaultTokenProviders(); //STAP 43 : Enable Token Generation
               //STAP 44: expire time for forgot pwd token
            services.Configure<DataProtectionTokenProviderOptions>(opt =>
                            opt.TokenLifespan = TimeSpan.FromHours(2));
            //STAP 33 ConfigureApplicationCookie
            //services.ConfigureApplicationCookie(o => o.LoginPath = "/Account/Login");
            /*So, next to the AddIdentity method call, we add the AddEntityFrameworkStores 
             * method to register the required EF Core implementation of Identity stores.
             *https://medium.com/@xsoheilalizadeh/asp-net-core-identity-deep-dive-stores-e0e54291b51d
             */
            //STAP 36: AddScoped CustomClaimsFactory
            services.AddScoped<IUserClaimsPrincipalFactory<IdentityUser>, CustomClaimsFactory>();

            services.AddAutoMapper(typeof(Startup)); //STAP 14
             //STAP 39: STAP email config and Email settings in appsettings.json
            var emailConfig = Configuration
                .GetSection("EmailConfiguration")
                .Get<EmailConfiguration>();
                services.AddSingleton(emailConfig);
                services.AddScoped<IEmailSender, EmailSender>();


            services.AddControllersWithViews();
        }

        // This method gets called by the runtime. Use this method to configure the HTTP request pipeline.
        public void Configure(IApplicationBuilder app, IWebHostEnvironment env)
        {
            if (env.IsDevelopment())
            {
                app.UseDeveloperExceptionPage();
            }
            else
            {
                app.UseExceptionHandler("/Home/Error");
                // The default HSTS value is 30 days. You may want to change this for production scenarios, see https://aka.ms/aspnetcore-hsts.
                app.UseHsts();
            }
            app.UseHttpsRedirection();
            app.UseStaticFiles();

            app.UseRouting();
            app.UseAuthentication();//STAP 24
            app.UseAuthorization();

            app.UseEndpoints(endpoints =>
            {
                endpoints.MapControllerRoute(
                    name: "default",
                    pattern: "{controller=Home}/{action=Index}/{id?}");
            });
        }
    }
}
