﻿using DemoMoqApi.Services;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;

namespace DemoMoqApi.Models
{
    public class Card : ICard
    {


        public Card(string v1, string v2, string v3)
        {
            this.CardNumber = v1;
            this.Name = v2;
            this.ValidTo = v3;
        }

        public string CardNumber { get; set; }
        public string Name { get; set; }
        public string ValidTo { get; set; }
    }


}
