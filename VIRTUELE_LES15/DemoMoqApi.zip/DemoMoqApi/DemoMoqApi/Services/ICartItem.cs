﻿namespace DemoMoqApi.Services
{
    public interface ICartItem
    {
        double Price { get; set; }
        string ProductId { get; set; }
        int Quantity { get; set; }
    }
}