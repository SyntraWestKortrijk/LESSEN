﻿using System;

namespace DemoMoqApi.Services
{
    public interface ICard
    {
        string CardNumber { get; set; }
        string Name { get; set; }
        string ValidTo { get; set; }
    }
}