﻿namespace DemoMoqApi.Services
{
    public interface IAddressInfo
    {
        string Address { get; set; }
        string City { get; set; }
        string PhoneNumber { get; set; }
        string PostalCode { get; set; }
        string Street { get; set; }
    }
}