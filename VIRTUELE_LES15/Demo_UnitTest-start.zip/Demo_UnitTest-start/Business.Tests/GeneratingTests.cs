﻿using NUnit.Framework;

namespace Business.Tests
{
    class GeneratingTests
    {
        [Test]
        public void bla_bla_bla()
        {

        }
    }
}
