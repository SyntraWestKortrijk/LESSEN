namespace Business
{
    public class Calculator
    {
        public int AddNumbers(int a, int b)
        {
            return a + b;
        }
    }
}