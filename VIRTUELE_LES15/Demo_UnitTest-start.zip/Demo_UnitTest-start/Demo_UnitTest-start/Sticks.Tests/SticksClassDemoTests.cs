using NUnit.Framework;

namespace Sticks.Tests
{
    [TestFixture]
    public class SticksClassDemoTests
    {
        [SetUp]
        public void Setup()
        {
        }

        [Test]
        public void Calculate_Default_Equals0()
        {
            //arrange
            SticksClassDemo obj = new SticksClassDemo();
            //act
            int result = obj.Calculate(1);
            //assert
            Assert.That(0, Is.EqualTo(result)); //;
        }
    }
}