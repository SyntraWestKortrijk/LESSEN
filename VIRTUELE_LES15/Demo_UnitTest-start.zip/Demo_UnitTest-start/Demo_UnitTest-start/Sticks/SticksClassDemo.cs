﻿using System;
using System.Collections.Generic;
using System.Text;

namespace Sticks
{
    public class SticksClassDemo
    {
        private int value1;
        private int value2;

        public SticksClassDemo(int val1=0, int val2=0)
        {
            value1 = val1;
            value2 = val2;
        }

        public int Calculate(int val3)
        {
            return value1 + value2 * val3/100;
        }
    }
}
