﻿using NUnit.Framework;
using System;
using System.Collections.Generic;
using System.Text;

namespace Business.Tests
{
    [TestFixture]
    public class DegreeConverterTests
    {
        [Test]
        public void ToFahrenheit_ZeroCelcius_Returns32() {
            var converter = new DegreeConverter();
            double result = converter.ToFahrenheit(0);
            Assert.That(result, Is.EqualTo(32));
        }
        [Test]
        public void ToCelcius_1Fahrenheit_Returns0() {
            var converter = new DegreeConverter();
            double result = converter.ToCelsius(1);
            Assert.That(result, Is.EqualTo(0));
        }
    }
}
