﻿using System;
using System.Collections.Generic;
using System.Text;
using Business;
using NUnit.Framework;

namespace Business.Tests
{
    [TestFixture]
    public class DegreeConverterTests
    {
        [Test]
        public void ToFahrenheit_ZeroCelcius_Returns32() {
            //arrange
            DegreeConverter converter = new DegreeConverter();
            //act
            double result = converter.ToFahrenheit(0);
            //assert
            Assert.That(result, Is.EqualTo(32));
        }
    }
}
