using CustomersApi.Dtos;
using CustomersApi.Repositories;
using CustomersApi.Services;
using System.Threading.Tasks;
using Moq;
using NUnit.Framework;
using System;

namespace CustomersApi.Tests
{
    [TestFixture]
    public class CustomerServiceTests
    {
        private readonly CustomerService _sut;
        private readonly Mock<ICustomerRepository> _customerRepoMock = new Mock<ICustomerRepository>();
        private readonly Mock<ILoggingService> _loggerMock = new Mock<ILoggingService>();
        public CustomerServiceTests()
        {
            _sut = new CustomerService(_customerRepoMock.Object,_loggerMock.Object);
        }

        [SetUp]
        public void Setup()
        {
        }

        [Test]
        public async Task GetByIdAsync_ShouldReturnCustomer_WhenCustomerExistsAsync()
        {
            // Arrange
            var customerId = Guid.NewGuid();
            var customerName = "Jos De Klos";
            var customerDto = new CustomerDto { Id = customerId.ToString(), FullName = customerName };
            _customerRepoMock.Setup(x=> x.GetByIdAsync(customerId)).ReturnsAsync(customerDto);
            //_customerRepository.GetByIdAsync(customerId).Returns(customerDto);

            // Act
            var customer = await _sut.GetByIdAsync(customerId);

            // Assert
            Assert.AreEqual(customerId, customer.Id);
            Assert.AreEqual(customerName, customer.FullName);
        }
        [Test]
        public async Task GetByIdAsync_ShouldReturnNothing_WhenCustomerDoesNotExist()
        {
            //Arrange
            _customerRepoMock.Setup(x => x.GetByIdAsync(It.IsAny<Guid>())).ReturnsAsync(()=>null);
            var customer = await _sut.GetByIdAsync(Guid.NewGuid());
            Assert.Null(customer);
        }
        [Test]
        public async Task GetByIdAsync_ShouldReturnNull_WhenCustomerDoesNotExist()
        {
            // Arrange
            //_customerRepository.GetByIdAsync(Arg.Any<Guid>()).ReturnsNull();

            // Act
            var customer = await _sut.GetByIdAsync(Guid.NewGuid());

            // Assert
            Assert.Null(customer);
        }

        [Test]
        public async Task GetByIdAsync_ShouldLogAppropriateMessage_WhenCustomerExists()
        {
            // Arrange
            var customerId = Guid.NewGuid();
            var customerName = "Jos De Klos";
            var customerDto = new CustomerDto { Id = customerId.ToString(), FullName = customerName };
            // _customerRepository.GetByIdAsync(customerId).Returns(customerDto);
            _customerRepoMock.Setup(x => x.GetByIdAsync(customerId)).ReturnsAsync(customerDto);
            // Act
            await _sut.GetByIdAsync(customerId);

            // Assert
            _loggerMock.Verify(x => x.LogInformation("Retrieved a customer with Id: {Id}", customerId), Times.Once);
            //_logging.Received(1).LogInformation("Retrieved a customer with Id: {Id}", customerId);
            //_logging.DidNotReceive().LogInformation("Unable to find a customer with Id: {Id}", customerId);
            _loggerMock.Verify(x => x.LogInformation("Unable to find a customer with Id: {Id}", customerId),Times.Never);
        }
    }
}