namespace CustomersApi.Dtos
{
    public class CustomerDto
    {
        public string Id { get; set; }

        public string FullName { get; set; }
    }
}