namespace Sticks.Core
{
    public enum Player
    {
        Machine,
        Human
    }
}