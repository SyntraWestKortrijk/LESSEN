﻿using System;
using System.Collections.Generic;
using System.ComponentModel.DataAnnotations;
using System.Linq;
using System.Threading.Tasks;

namespace MyMVCApp.Models
{
    public class Category
    {
        [Key]
        public int Id { get; set; }
        [Display(Name="Naam van Categorie")]
        [Required(ErrorMessage = "Ge moet nen tekst ingeven dommy!")]
        [StringLength(10,ErrorMessage = "Den tekst mag niet langer zijn dan 10 karakter, stommerd!")]
        public string Name { get; set; }
    }
}
