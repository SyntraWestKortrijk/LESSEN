﻿using Microsoft.AspNetCore.Identity.EntityFrameworkCore;
using Microsoft.EntityFrameworkCore;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;

namespace EmployeeManager.Mvc.Security
{
    public class AppIdentityDbContext:IdentityDbContext<AppIdentityUser, AppIdentityRole,string>
    {//TO DO registratie als service via DI Container (rugzak klaarzetten)
        public AppIdentityDbContext(DbContextOptions<AppIdentityDbContext> options) : base(options) { 
        
        }
    }
}
