﻿using EmployeeManager.Mvc.Models;
using EmployeeManager.Mvc.Security;
using Microsoft.AspNetCore.Identity;
using Microsoft.AspNetCore.Mvc;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;

namespace EmployeeManager.Mvc.Controllers
{
    public class SecurityController:Controller
    {
        private readonly RoleManager<AppIdentityRole> roleManager;
        private readonly UserManager<AppIdentityUser> userManager;
        private readonly SignInManager<AppIdentityUser> signinManager;
        public SecurityController(UserManager<AppIdentityUser> userManager, RoleManager<AppIdentityRole> roleManager,
    SignInManager<AppIdentityUser> signinManager)
        {
            this.userManager = userManager;
            this.roleManager = roleManager;
            this.signinManager = signinManager;
        }


        //Wat heb ik nodig van action methods:
        //httpGet Register()
        public IActionResult Register() {
            return View();
        }
        //httpPost Register() action method
        [HttpPost]
        public IActionResult Register(Register obj) {
            //eerst checken of alle input-validaties ok zijn hoe doe ik dat?
            if (ModelState.IsValid)
            {
                if (!roleManager.RoleExistsAsync("Manager").Result) {
                    //Als er nog geen Rol Manager bestaat in de db, gaan we deze aanmaken
                    AppIdentityRole role = new AppIdentityRole();
                    role.Name = "Manager";
                    role.Description = "Can perform CRUD operations";
                    IdentityResult roleResult = roleManager.CreateAsync(role).Result; 
                    //AspNetRoles 
                }
                AppIdentityUser user = new AppIdentityUser();
                user.UserName = obj.UserName;
                user.Email = obj.Email;
                user.FullName = obj.FullName;
                user.BirthDate = obj.BirthDate;
                //nieuwe user creëren in de database (AspNetUsers)
                IdentityResult result = userManager.CreateAsync(user, obj.Password).Result;
                if (result.Succeeded) {
                    //we gaan bv alle users direct de manager role geven
                    userManager.AddToRoleAsync(user,"Manager").Wait();
                }
                else {
                    ModelState.AddModelError("", "Invalid User Details..");
                    RetrieveErrors(result.Errors);
              
                    //niet gelukt: boodschap terug geven
                }
            }
            return View(obj);

        }
        private void RetrieveErrors(IEnumerable<IdentityError> errorList)
        {
            foreach (IdentityError error in errorList)
                ModelState.AddModelError("", error.Description);
        }
    }
}
